# C++ project

## Instruction

1. Run `__Standard_G++_Creation.bat`.

2. Give the project name.

3. Modify `Main.cpp` file code.

## Execution

* By terminal `.\src\__Standard_G++_Compilation.bat`.

* By double-clicking `__Standard_G++_Execution.bat`.