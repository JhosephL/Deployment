# C project

## Instruction

1. Run `__Standard_GCC_Creation.bat`.

2. Give the project name.

3. Modify `Main.c` file code.

## Execution

* By terminal `.\src\__Standard_GCC_Compilation.bat`.

* By double-clicking `__Standard_GCC_Execution.bat`.