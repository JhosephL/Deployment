# Java Swing project

## Instruction

1. Run `__Standard_Swing_Creation.bat`.

2. Give the project name.

3. Modify `Main.java` file code.

## Execution

* By terminal `.\src\__Standard_Swing_Compilation.bat`.

* By double-clicking `__Standard_Swing_Execution.bat`.