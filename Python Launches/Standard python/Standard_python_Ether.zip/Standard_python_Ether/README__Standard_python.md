# Python project

## Instruction

1. Run `__Standard_python_Creation.bat`.

2. Give the project name.

3. Modify `Main.py` file code.

## Execution

* By terminal `.\src\__Standard_python_Compilation.bat`.

* By double-clicking `__Standard_python_Execution.bat`.